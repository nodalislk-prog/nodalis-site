NODALIS — hero video slots (three portrait reels)
Upload portrait MP4 videos named EXACTLY:

hero.mp4    -> left reel
hero2.mp4   -> middle reel
hero3.mp4   -> right reel

Rules:
- Portrait orientation (phone videos are perfect)
- MP4 in H.264 (if a video won't play in Chrome, send it to Claude to convert)
- 10-30 seconds each, they loop automatically, muted
- Keep each under ~15 MB

Any missing slot shows an elegant placeholder. On phones only the
first reel shows, full width.
